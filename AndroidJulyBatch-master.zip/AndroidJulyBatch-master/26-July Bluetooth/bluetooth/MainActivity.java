package com.bmpl.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Switch aSwitch;
    Button visible, pairedDevice;
    ListView listView;
    //Bluetooth Adpater
    BluetoothAdapter bluetoothAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //bluetooth driver information-->
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        aSwitch = (Switch)findViewById(R.id.bluetoothSwitch);

        visible = (Button)findViewById(R.id.visibleButton);

        pairedDevice = (Button)findViewById(R.id.pairedDevice);

        listView = (ListView)findViewById(R.id.listView);

        if(bluetoothAdapter.isEnabled())
        {
            aSwitch.setChecked(true);
        } else {
            aSwitch.setChecked(false);
        }

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if(bluetoothAdapter == null){

                    Toast.makeText(MainActivity.this, "Bluetooth Driver is not Available", Toast.LENGTH_SHORT).show();

                } else if(!bluetoothAdapter.isEnabled()){
                    //Implicit intent
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivity(intent);

                } else if(bluetoothAdapter.isEnabled()) {

                    bluetoothAdapter.disable();//off

                }
            }
        });


        visible.setOnClickListener(this);
        pairedDevice.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

    }
}
