package com.bmpl.sharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button submitButton;
    EditText nameEditText, passwordEditText;
    TextView resultTextView;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submitButton = (Button)findViewById(R.id.submitButton);
        nameEditText = (EditText)findViewById(R.id.userNameEditText);
        passwordEditText = (EditText)findViewById(R.id.passwordEditText);
        resultTextView = (TextView)findViewById(R.id.resultTextView);

        sharedPreferences = getSharedPreferences("userData", MODE_PRIVATE);

        readData();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = nameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                //writing to the shared preference
                //SharedPreferences sharedPreferences = getSharedPreferences("userData", MODE_PRIVATE);
                //per activity data storage/ no need to share data between activities
                SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
                // data req. to be shared among activities

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("name", name);
                editor.putString("password", password);
                editor.commit();//synchronous manner
                editor.apply();//async manner
            }
        });
    }

    private void readData(){
        //per activity data storage/ no need to share data between activities
        SharedPreferences sharedPreferences = getPreferences(MODE_PRIVATE);
        // data req. to be shared among activities
        //SharedPreferences sharedPreferences = getSharedPreferences("userData", MODE_PRIVATE);
        resultTextView.setText(sharedPreferences.getString("name", "") + "\n" +
        sharedPreferences.getString("password", ""));
    }
}


