package com.bmpl.sqlitedatabase;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

//Database--> SQLite Database-->
public class DatabaseHandler extends SQLiteOpenHelper{

    //Context context;
    private static final String DATABASE_NAME = "MyDatabase";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "UserDetails";
    private static final String COLUMN_NAME = "Name";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_PHONE = "Phone";

    private static final String CREATE_TABLE = "create table " + TABLE_NAME +
                                                "( " + COLUMN_ID + "INTEGER PRIMARY KEY," +
                                                COLUMN_NAME + " TEXT, " +
                                                COLUMN_PHONE + " INTEGER )";


    public DatabaseHandler(Context context) {
        //database create
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

/*    public DatabaseHandler(Context context){
        //super();
    }*/


    //table created
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
        Log.i("Database Handler", "Table created");
    }

    //upgradation--> database version --> database upgrade
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

    }

    public void addData(Details details){
        SQLiteDatabase sqliteDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, details.getName());
        contentValues.put(COLUMN_ID, details.getId());
        contentValues.put(COLUMN_PHONE, details.getPhoneNumber());

        //sqliteDatabase.insert(TABLE_NAME, null, contentValues);
        sqliteDatabase.insertOrThrow(TABLE_NAME, null, contentValues);

        sqliteDatabase.close();
    }

    public void readData()
    {
        ArrayList arrayList = new ArrayList();

        SQLiteDatabase sqliteDatabase = this.getReadableDatabase();
        String readQuery = "select * from " + TABLE_NAME;
        Cursor cursor = sqliteDatabase.rawQuery(readQuery, null);

        //int column_id =  cursor.getInt(0);

        while (cursor.moveToNext()){
            String column_id = cursor.getString(0);
            String column_name = cursor.getString(1);
            String columnPhn = cursor.getString(2);
        }


        //arrayList.add(sqliteDatabase.execSQL(readQuery));

        /*ContentValues contentValues = new ContentValues();
        contentValues.getAsString(COLUMN_NAME);*/

    }

    public void updateData(Details details){

    }

    public void deleteData(Details details){

    }
}

