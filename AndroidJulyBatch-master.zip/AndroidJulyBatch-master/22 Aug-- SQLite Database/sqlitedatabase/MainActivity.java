package com.bmpl.sqlitedatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    DatabaseHandler databaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHandler = new DatabaseHandler(this);

        databaseHandler.addData(new Details(1, "Ram", 98325432));
        databaseHandler.addData(new Details(2, "Rohan", 9932323));
        databaseHandler.addData(new Details(3, "Reena", 98325432));
        databaseHandler.addData(new Details(4, "mohan", 9732322));
    }
}
