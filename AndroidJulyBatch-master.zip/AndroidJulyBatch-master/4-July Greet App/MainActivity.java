package com.bmpl.greetapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button submit, cancel;
    EditText nameEditText, salaryEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);// front-end--> layout back-end--> activity

        submit = (Button)findViewById(R.id.submitButton);
        //R is a predefined java class--> R.java--> hold reference of everything
        cancel = (Button)findViewById(R.id.cancelButton);

        nameEditText = (EditText) findViewById(R.id.nameEditText);


    }
}
