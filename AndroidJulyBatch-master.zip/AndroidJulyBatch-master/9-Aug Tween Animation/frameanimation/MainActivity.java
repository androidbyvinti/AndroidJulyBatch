package com.bmpl.frameanimation;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Button startButton;

    //Control view--> widget
    Animation animation;

    //Frame
    AnimationDrawable animationDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = (Button)findViewById(R.id.button);

        imageView = (ImageView)findViewById(R.id.imageView);

        animation = AnimationUtils.loadAnimation(this, R.anim.rotate_anim);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                imageView.startAnimation(animation);
                animation.cancel();

            }
        });

        /*imageView.setBackgroundResource(R.drawable.walk_animation);

        animationDrawable = (AnimationDrawable) imageView.getBackground();

        animationDrawable.start();*/

    }
}
