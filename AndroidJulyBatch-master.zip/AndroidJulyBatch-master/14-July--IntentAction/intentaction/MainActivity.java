package com.bmpl.intentaction;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sendData(View view){

        try {
            //intent action
            /*Intent intent = new Intent();
            intent.setAction(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, "This is data from my app");
            startActivity(Intent.createChooser(intent, "Select one"));*/
            //startActivity(intent);

            //MIME Type
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, "Body");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"abc@gmail.com"});
            intent.putExtra(Intent.ACTION_ATTACH_DATA, R.mipmap.ic_launcher);
            startActivity(Intent.createChooser(intent, "Select One"));
        }

        catch (ActivityNotFoundException e){
            Toast.makeText(this, "No activity to handle data", Toast.LENGTH_SHORT).show();
        }

        catch (Exception e){
            Toast.makeText(this, "Some other exception occured", Toast.LENGTH_SHORT).show();
        }
    }
}