package com.bmpl.autocomtextview;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView autoCompleteTextView;

    WebView webView;

    ArrayAdapter arrayAdapter;

    String values[] = { "Cupcake", "Donut", "Eclair", "Froyo",
                        "Gingerbread", "HoneyComb", "Icecream Sandwich",
                        "JellyBean", "Kitkat", "Lollipop", "Marshmallow",
                        "Nougat", "O coming"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView)findViewById(R.id.webView);

        autoCompleteTextView = (AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);

        arrayAdapter = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, values);

        autoCompleteTextView.setAdapter(arrayAdapter);

        webView.loadUrl("https://www.google.co.in/?gfe_rd=cr&ei=toONWbCsC7KA8Qfm5KWAAQ");
        webView.setWebViewClient(new CustomLoad());

        webView.getSettings().setJavaScriptEnabled(true);

    }

    class CustomLoad extends WebViewClient{

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

           String url =  request.getUrl().toString();

            return true;
        }
    }

}
