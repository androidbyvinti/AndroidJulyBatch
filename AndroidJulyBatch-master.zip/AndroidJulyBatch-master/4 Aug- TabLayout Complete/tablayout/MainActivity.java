package com.bmpl.tablayout;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    int icons[] = {R.mipmap.ic_launcher, R.mipmap.ic_launcher};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        //custom method
        setUpFragment(viewPager);//fragement data
        //predefined method
        tabLayout.setupWithViewPager(viewPager);
        setTabIcons();
    }

    void setTabIcons(){
        tabLayout.getTabAt(0).setIcon(icons[0]);
        tabLayout.getTabAt(1).setIcon(icons[1]);
    }

    //default --> access inside package
    void setUpFragment(ViewPager viewPager){

        FragmentPager fragmentPager = new FragmentPager(getSupportFragmentManager());
        //CallFragment callFragment = new CallFragment();
        fragmentPager.add(new CallFragment(), "Call");
        fragmentPager.add(new ContactsFragment(), "Contacts");
        viewPager.setAdapter(fragmentPager);
    }

    class FragmentPager extends FragmentPagerAdapter{

        ArrayList<Fragment> fragmentList = new ArrayList();
        ArrayList<String> titleList = new ArrayList<>();


        public FragmentPager(FragmentManager fm) {
            super(fm);
        }

        void add(Fragment fragment, String title){
            fragmentList.add(fragment);
            titleList.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return null;
            //return titleList.get(position);
        }
    }
}
