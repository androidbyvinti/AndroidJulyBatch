package com.bmpl.quizapp;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, RadioGroup.OnCheckedChangeListener, CompoundButton.OnCheckedChangeListener, View.OnClickListener /*, CompoundButton.OnCheckedChangeListener*/ {

    Button submitButton;
    TextView seekBarTextView;
    SeekBar seekBar;
    RadioGroup radioGroup;
    RadioButton dataBridge, designBridge, debugBridge, radioButton;
    CheckBox aot, jit, none;
    static int score;
    int selectedId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();

    }

    void initialize(){
        submitButton = (Button)findViewById(R.id.submitButton);
        seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBarTextView = (TextView)findViewById(R.id.seekTextView);
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        dataBridge = (RadioButton)findViewById(R.id.dataBridge);
        designBridge = (RadioButton)findViewById(R.id.designBridge);
        debugBridge = (RadioButton)findViewById(R.id.debugBridge);
        aot = (CheckBox)findViewById(R.id.aotCheckBox);
        jit = (CheckBox)findViewById(R.id.jitCheckBox);
        none = (CheckBox)findViewById(R.id.noCompilerCheckBox);

        seekBar.setOnSeekBarChangeListener(this);

        radioGroup.setOnCheckedChangeListener(this);

        aot.setOnCheckedChangeListener(this);
        jit.setOnCheckedChangeListener(this);
        none.setOnCheckedChangeListener(this);

        submitButton.setOnClickListener(this);

        //dataBridge.setOnCheckedChangeListener(this);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        seekBarTextView.setText(i + "/" + seekBar.getMax());
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    //RadioGroup Handler
    @Override
    public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
        //clicked radio button id in i
        selectedId = i;
    }
    //CheckBox Handler
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

    }

    @Override
    public void onClick(View view) {

        Intent intent = new Intent(MainActivity.this, ScoreActivity.class);

        radioButton = (RadioButton)findViewById(selectedId);
        if(radioButton == debugBridge){
            score++;
            Log.d("MainActivity", "score = " + score);
        }

        if(aot.isChecked() && jit.isChecked() && !none.isChecked()){
            score++;
            Log.d("MainActivity", "Score in checkbox= " + score);
        }/* else {
            score--;
        }*/

        startActivity(intent);
    }

/*    //RadioButton Handler
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

    }*/
}
