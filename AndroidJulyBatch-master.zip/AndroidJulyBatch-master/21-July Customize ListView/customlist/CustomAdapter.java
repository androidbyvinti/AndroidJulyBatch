package com.bmpl.customlist;


import android.content.Context;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter{


    String[] data;
    int[] images;
    Context context;

    //whenever u are dealing with adapter or fragments and
    // u need to set the layout then LayoutInflater comes into use.
    LayoutInflater layoutInflater;

    CustomAdapter(Context context, String[] data, int[] images){
        this.context = context;
        this.data = data;
        this.images = images;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return data.length;//data return length or size of array
    }

    @Override
    public Object getItem(int i) {
        return data[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        //setContentView(R.layout.custom_adapter);

        view = layoutInflater.inflate(R.layout.custom_adapter, viewGroup, false);

        ImageView imageView = (ImageView)view.findViewById(R.id.imageView);
        TextView textView = (TextView)view.findViewById(R.id.textView);

        imageView.setImageResource(images[position]);
        textView.setText(data[position]);

        return view;
    }
}
