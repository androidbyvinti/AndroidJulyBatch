package com.bmpl.greetapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView resultTextView;
    Button submit, cancel;
    EditText nameEditText, salaryEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);// front-end--> layout back-end--> activity

        //Step-1: Downcasting

        submit = (Button)findViewById(R.id.submitButton);
        //R is a predefined java class--> R.java--> hold reference of everything
        cancel = (Button)findViewById(R.id.cancelButton);

        nameEditText = (EditText) findViewById(R.id.nameEditText);

        salaryEditText = (EditText)findViewById(R.id.salaryEditText);

        resultTextView = (TextView)findViewById(R.id.resultTextView);

        //Step-2: Attach Listener
        //anonymous way--> inner class create --> no name --> no name of object
        submit.setOnClickListener(new View.OnClickListener() {

            //Step-3: Attach Handler
            @Override
            public void onClick(View view) {

                String name = nameEditText.getText().toString();

                //Reference type --> ==
                String salary = salaryEditText.getText().toString();

                if (name.equals("") || salary.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Fill Your Details First", Toast.LENGTH_LONG).show();

                }
                else {
                    resultTextView.setText("Welcome " + name + "\n" + salary);

                    Toast.makeText(MainActivity.this, "Submitted", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nameEditText.setText("");
                salaryEditText.setText("");
                resultTextView.setText("");

            }
        });


    }
}
